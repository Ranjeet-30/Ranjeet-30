# Ranjeet-30 GitHub Profile

This folder contains the first version of the custom profile README.

## Install

1. Create a **public** repository named exactly `Ranjeet-30`.
2. Put `README.md` at the repository root.
3. Put the `assets/` folder and `.github/workflows/generate-snake.yml` in the same repository.
4. Commit and push.
5. Open `https://github.com/Ranjeet-30`.

The profile README is displayed because GitHub recognizes a public repository whose name exactly matches the username.
